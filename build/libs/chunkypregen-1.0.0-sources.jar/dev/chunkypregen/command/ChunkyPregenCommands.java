package dev.chunkypregen.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.chunkypregen.config.ChunkyPregenConfig;
import dev.chunkypregen.generation.DimensionState;
import dev.chunkypregen.generation.GenerationTracker;
import dev.chunkypregen.generation.StateSerializer;
import dev.chunkypregen.integration.VoxyIntegration;
import dev.chunkypregen.monitor.ProgressRelay;
import dev.chunkypregen.monitor.SessionStats;
import dev.chunkypregen.monitor.TpsMonitor;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_12087;
import net.minecraft.class_12090;
import net.minecraft.class_12094;
import net.minecraft.class_12095;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7157;
import net.minecraft.class_7924;
import java.util.List;
import java.util.Map;

import static net.minecraft.class_2170.method_9247;

/**
 * All /chunkypregen sub-commands.
 *
 * Permission level: GAMEMASTERS (op level 2) for all commands.
 * Uses the MC 1.21.11 permission API (PermissionSourcePredicate + PermissionCheck.Require).
 * Theoretically compatible with any MC version that uses this permission system (1.20.5+).
 * Older versions (pre-1.20.5) used hasPermissionLevel(int) — see project memory for details.
 */
public class ChunkyPregenCommands {

    private static final List<class_5321<class_1937>> ALL_DIMS =
            List.of(GenerationTracker.OVERWORLD, GenerationTracker.NETHER, GenerationTracker.END);

    // Requires op level 2 (GAMEMASTERS) via 1.21.11 permission API
    @SuppressWarnings("unchecked")
    private static final java.util.function.Predicate<class_2168> OP2 =
            new class_12095<>(new class_12090.class_12092(
                    new class_12087.class_12089(class_12094.field_63198)));

    public static void register() {
        CommandRegistrationCallback.EVENT.register(ChunkyPregenCommands::registerCommands);
    }

    private static void registerCommands(CommandDispatcher<class_2168> dispatcher,
                                         class_7157 reg,
                                         class_2170.class_5364 env) {
        dispatcher.register(
            method_9247("chunkypregen").requires(OP2)

            // ── status ──────────────────────────────────────────────────────
            .then(method_9247("status").executes(ctx -> {
                sendStatus(ctx.getSource());
                return 1;
            }))

            // ── trigger [dimension] ──────────────────────────────────────────
            .then(method_9247("trigger")
                .executes(ctx -> { triggerAll(ctx.getSource()); return 1; })
                .then(class_2170.method_9244("dimension", StringArgumentType.word())
                    .executes(ctx -> {
                        triggerDim(ctx.getSource(), StringArgumentType.getString(ctx, "dimension"));
                        return 1;
                    })))

            // ── cancel ───────────────────────────────────────────────────────
            .then(method_9247("cancel").executes(ctx -> {
                GenerationTracker.cancelAll(ctx.getSource().method_9211());
                ctx.getSource().method_9226(() -> class_2561.method_43470("§aCancelled all active Chunky jobs."), false);
                return 1;
            }))

            // ── reset [dimension] ────────────────────────────────────────────
            .then(method_9247("reset")
                .executes(ctx -> {
                    GenerationTracker.clearAllCenters();
                    ctx.getSource().method_9226(() -> class_2561.method_43470("§aCleared all last-center positions."), false);
                    return 1;
                })
                .then(class_2170.method_9244("dimension", StringArgumentType.word())
                    .executes(ctx -> {
                        String dimStr = StringArgumentType.getString(ctx, "dimension");
                        class_5321<class_1937> key = class_5321.method_29179(class_7924.field_41223, class_2960.method_60654(dimStr));
                        GenerationTracker.clearCenter(key);
                        ctx.getSource().method_9226(() -> class_2561.method_43470("§aCleared last-center for " + dimStr + "."), false);
                        return 1;
                    })))

            // ── setworld ─────────────────────────────────────────────────────
            .then(method_9247("setworld")
                .then(method_9247("reset").executes(ctx -> {
                    StateSerializer.clearWorldInitFlag(ctx.getSource().method_9211());
                    ctx.getSource().method_9226(() -> class_2561.method_43470(
                        "§aWorld init flag cleared. Next player join will trigger automatic pre-generation."), false);
                    return 1;
                }))
                .then(method_9247("initialized").executes(ctx -> {
                    StateSerializer.markWorldInitialized(ctx.getSource().method_9211());
                    ctx.getSource().method_9226(() -> class_2561.method_43470(
                        "§aWorld marked as initialized. Automatic new-world pre-gen will not trigger again."), false);
                    return 1;
                })))

            // ── stats ────────────────────────────────────────────────────────
            .then(method_9247("stats").executes(ctx -> {
                sendStats(ctx.getSource());
                return 1;
            }))

            // ── debug ────────────────────────────────────────────────────────
            .then(method_9247("debug").executes(ctx -> {
                ChunkyPregenConfig cfg = ChunkyPregenConfig.INSTANCE;
                cfg.debugMode = !cfg.debugMode;
                cfg.save();
                ctx.getSource().method_9226(() -> class_2561.method_43470(
                    "§aDebug mode: " + (cfg.debugMode ? "ON" : "OFF")), false);
                return 1;
            }))

            // ── reload ───────────────────────────────────────────────────────
            .then(method_9247("reload").executes(ctx -> {
                ChunkyPregenConfig.INSTANCE.reload();
                VoxyIntegration.invalidateCache();
                ctx.getSource().method_9226(() -> class_2561.method_43470("§aConfig reloaded from disk."), false);
                return 1;
            }))

            // ── config ───────────────────────────────────────────────────────
            .then(method_9247("config").executes(ctx -> {
                printConfig(ctx.getSource());
                return 1;
            }))
        );
    }

    // ── Command implementations ────────────────────────────────────────────────

    private static void sendStatus(class_2168 src) {
        ChunkyPregenConfig cfg = ChunkyPregenConfig.INSTANCE;
        double tps = TpsMonitor.getTps(src.method_9211());

        src.method_9226(() -> class_2561.method_43470("§6=== Chunky Pregenerator Status ==="), false);
        src.method_9226(() -> class_2561.method_43470(
            "§7Enabled: §f" + cfg.enabled +
            "  Chunky: §f" + GenerationTracker.chunkyAvailable +
            "  TPS: §f" + String.format("%.1f", tps) +
            (GenerationTracker.isTpsPaused() ? " §c(paused)" : "")), false);
        src.method_9226(() -> class_2561.method_43470(
            "§7Trigger: §f" + cfg.triggerDistance + " blocks" +
            "  Radius: §f" + cfg.generationRadius + " chunks" +
            "  Threads: §f" + cfg.chunkyThreads), false);

        if (VoxyIntegration.PRESENT) {
            int vr = VoxyIntegration.getRenderDistanceChunks();
            src.method_9226(() -> class_2561.method_43470("§7Voxy radius: §f" + vr + " chunks"), false);
        }

        src.method_9226(() -> class_2561.method_43470("§7End visited: §f" + GenerationTracker.isEndVisited()), false);

        for (class_5321<class_1937> dim : ALL_DIMS) {
            DimensionState state   = GenerationTracker.getState(dim);
            class_2338       last    = GenerationTracker.getLastCenter(dim);
            String         lastStr = last != null ? last.method_10263() + ", " + last.method_10260() : "none";

            String progress = ProgressRelay.getLatestProgress().get(dim.method_29177().toString());
            String progressStr = progress != null ? "  progress: §f" + progress : "";

            // Show spiral ring progress if a batch is in flight
            String spiralStr = "";
            int ringNum    = GenerationTracker.getBatchRingNumber(dim);
            int totalRings = GenerationTracker.getBatchTotalRings(dim);
            int curRadius  = GenerationTracker.getBatchCurrentRadius(dim);
            int tgtRadius  = GenerationTracker.getBatchTargetRadius(dim);
            if (ringNum > 0 && totalRings > 0) {
                spiralStr = "  ring §f" + ringNum + "§7/§f" + totalRings
                          + " §7(§f" + curRadius + "§7/§f" + tgtRadius + " §7chunks)";
            }

            final String line = "§7" + GenerationTracker.dimName(dim) + ": §f" + state + "  last=" + lastStr + progressStr + spiralStr;
            src.method_9226(() -> class_2561.method_43470(line), false);
        }
    }

    private static void sendStats(class_2168 src) {
        src.method_9226(() -> class_2561.method_43470("§6=== Chunky Pregenerator Session Stats ==="), false);

        long activeMs = SessionStats.getActiveMs();
        long secs  = activeMs / 1000;
        long mins  = secs / 60;
        long hours = mins / 60;
        String duration = hours > 0
            ? hours + "h " + (mins % 60) + "m"
            : mins > 0 ? mins + "m " + (secs % 60) + "s" : secs + "s";

        src.method_9226(() -> class_2561.method_43470("§7Active time this session: §f" + duration), false);

        for (class_5321<class_1937> dim : ALL_DIMS) {
            int  jobs     = SessionStats.getJobsFired().getOrDefault(dim, 0);
            long estimate = SessionStats.getChunksEstimated().getOrDefault(dim, 0L);
            if (jobs == 0) continue;
            String dimShort = dim.method_29177().method_12832().replace("the_", "");
            final String line = "§7" + dimShort + ": §f" + jobs + " job" + (jobs == 1 ? "" : "s") +
                                "  ~" + String.format("%,d", estimate) + " chunks";
            src.method_9226(() -> class_2561.method_43470(line), false);
        }
    }

    private static void printConfig(class_2168 src) {
        ChunkyPregenConfig cfg = ChunkyPregenConfig.INSTANCE;
        src.method_9226(() -> class_2561.method_43470("§6=== Chunky Pregenerator Config ==="), false);
        src.method_9226(() -> class_2561.method_43470("§7enabled: §f" + cfg.enabled + "  debugMode: §f" + cfg.debugMode), false);
        src.method_9226(() -> class_2561.method_43470("§7triggerDistance: §f" + cfg.triggerDistance + "  generationRadius: §f" + cfg.generationRadius), false);
        src.method_9226(() -> class_2561.method_43470("§7overworldRadius: §f" + cfg.overworldRadius + "  netherRadius: §f" + cfg.netherRadius + "  endRadius: §f" + cfg.endRadius), false);
        src.method_9226(() -> class_2561.method_43470("§7checkIntervalTicks: §f" + cfg.checkIntervalTicks + "  spiralGeneration: §f" + cfg.spiralGeneration + "  ringStep: §f" + cfg.generationRingStep + " chunks"), false);
        src.method_9226(() -> class_2561.method_43470("§7enableOverworld: §f" + cfg.enableOverworld + "  enableNether: §f" + cfg.enableNether + "  enableEnd: §f" + cfg.enableEnd), false);
        src.method_9226(() -> class_2561.method_43470("§7netherAutoScale: §f" + cfg.netherAutoScale), false);
        src.method_9226(() -> class_2561.method_43470("§7requireEndVisit: §f" + cfg.requireEndVisit + "  minPlayersToTrigger: §f" + cfg.minPlayersToTrigger), false);
        src.method_9226(() -> class_2561.method_43470("§7skipCreative: §f" + cfg.skipCreativePlayers + "  skipSpectator: §f" + cfg.skipSpectatorPlayers), false);
        src.method_9226(() -> class_2561.method_43470("§7autoTpsPause: §f" + cfg.autoTpsPause + "  pauseAt: §f" + cfg.tpsPauseThreshold + " TPS  resumeAt: §f" + cfg.tpsResumeThreshold + " TPS"), false);
        src.method_9226(() -> class_2561.method_43470("§7progressRelay: §f" + cfg.progressRelay + "  every §f" + cfg.progressRelayIntervalMinutes + "min"), false);
        src.method_9226(() -> class_2561.method_43470("§7voxyIntegration: §f" + cfg.voxyIntegration + "  voxyRenderDistance: §f" + cfg.voxyRenderDistance + "  shape: §f" + cfg.shape), false);
    }

    private static void triggerAll(class_2168 src) {
        ChunkyPregenConfig cfg = ChunkyPregenConfig.INSTANCE;
        if (cfg.enableOverworld) triggerDim(src, "minecraft:overworld");
        if (cfg.enableNether)    triggerDim(src, "minecraft:the_nether");
        if (cfg.enableEnd)       triggerDim(src, "minecraft:the_end");
    }

    private static void triggerDim(class_2168 src, String dimStr) {
        class_5321<class_1937> key = class_5321.method_29179(class_7924.field_41223, class_2960.method_60654(dimStr));
        class_2338 center = class_2338.field_10980;
        if (src.method_9211() != null) {
            for (var player : src.method_9211().method_3760().method_14571()) {
                if (player.method_51469().method_27983().equals(key)) {
                    center = player.method_24515();
                    break;
                }
            }
        }
        final class_2338 finalCenter = center;
        GenerationTracker.maybeFireJob(src.method_9211(), key, finalCenter);
        src.method_9226(() -> class_2561.method_43470(
            "§aTriggered generation for " + dimStr + " at " + finalCenter.method_10263() + ", " + finalCenter.method_10260()), false);
    }
}
